<header class="header">

   <div class="flex">

      <a href="#" class="logo">Byte Cafe</a>

      <nav class="navbar">
	     <a href="admin_home.php">Home</a>
         <a href="admin.php">add products</a>
         <a href="product_admin.php">view products</a>
		 <a href="about_user.php">about</a>
        <a href="contact_user.php">contact</a>
      </nav>

      <?php
      
      $select_rows = mysqli_query($conn, "SELECT * FROM `cart`") or die('query failed');
      $row_count = mysqli_num_rows($select_rows);
      ?>

      <a href="cart_admin.php" class="cart">cart <span><?php echo $row_count; ?></span> </a>

      <div id="menu-btn" class="fas fa-bars"></div>

   </div>

</header>