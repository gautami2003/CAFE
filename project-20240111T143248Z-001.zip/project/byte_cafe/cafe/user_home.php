<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Byte Cafe</title>

	<!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	
    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

<!-- ChatBot -->
<link rel="stylesheet" type="text/css" href="css/jquery.convform.css">
<script type="text/javascript" src="css/js/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="css/js/jquery.convform.js"></script>
<script type="text/javascript" src="css/js/custom.js"></script>
</head>
	
<!-- header section starts  -->

<header class="header">

    <a href="home.php" class="logo"> <i class="fas fa-"></i> Byte Cafe	 </a>

    <nav class="navbar">
        <a href="user_home.php">home</a>
        <a href="product_user.php">menu</a>
        <a href="about_user.php">about</a>
        <a href="review.php">review</a>
        <a href="contact.php">contact</a>
		<a href="cart_user.php">Go to Cart</a>
    </nav>

    <form action="cart.php" method="post">
    
	<a href="logout.php"><h1>LogOut</h1></a>
    
</header>

<!-- header section ends -->


<body>
<!-- ChatBot -->
<div class="chat_icon">
	<i class="fa fa-comments" aria-hidden="true"></i>
</div>

<div class="chat_box">
	<div class="my-conv-form-wrapper">
		<form action="" method="GET" class="hidden">

      <select data-conv-question="Hello! How can I help you" name="category">
        <option value="Menu">Menu</option>
        <option value="About">About Us</option>
      </select>

      <div data-conv-fork="category">
        <div data-conv-case="Menu">
		<input type="text" name="name" data-conv-question="Alright! First, tell me your full name, please.|Okay! Please, tell me your name first.">
		<input type="text" data-conv-question="Howdy, {name}:0! It's a pleasure to meet you. " data-no-answer="true">
	    <input type="text" data-conv-question="<h1>Byte Cafe</h1> Welcomes you to our cafe" data-no-answer="true">
	    <select name="multi[]" data-conv-question="What would you like to have" multiple>
	    <option value="Cappicino">Cappicino</option>
	    <option value="Lattee">Lattee</option>
	    <option value="Doppiio">Doppiio</option>
	    <option value="Classic">Classic</option>
		</select>
		<select name="size" data-callback="storeState" data-conv-question="Which Size">
	        <option value="large">Large</option>
			<option value="meduim">Medium</option>
	        <option value="small">Small</option>
	    </select>
		<div data-conv-fork="size">
	        <div data-conv-case="large">
	        <input type="text" data-conv-question="Cool You have selected as large size." data-no-answer="true">
	        </div>
	        <div data-conv-case="medium">
		     <input type="text" data-conv-question="Cool You have selected as medium size." data-no-answer="true">
	        </div>
			<div data-conv-case="medium">
		    <input type="text" data-conv-question="Cool You have selected as medium size." data-no-answer="true">
	        </div>
			<input type="text" data-conv-question="Verify:" data-no-answer="true">
	        <input data-conv-question="Type in your e-mail" data-pattern="^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$" id="email" type="email" name="email" required placeholder="What's your e-mail?">
	        <input data-conv-question="Now tell me a secret (like a password)" type="password" data-minlength="6" id="senha" name="password" required placeholder="password">
			<select data-conv-question="Select the coffee you would like to Add to Your Cart or procceed for payment">
			<option value="order" data-callback="order">Menu</option>
			<option value="order" data-callback="order">Cart</option>
			</select>
	                                
	    </div>
		</div>
</div>
<div data-conv-fork="category">
        <div data-conv-case="About">
		<input type="text" name="name" data-conv-question="Alright! First, tell me your full name, please.|Okay! Please, tell me your name first.">
		<input type="text" data-conv-question="Howdy, {name}:0! It's a pleasure to meet you. " data-no-answer="true">
	    <input type="text" data-conv-question="<h1>Byte Cafe</h1> Welcomes you to our cafe Our Cafe Gives you Tremendous taste of wisely choose Coffee " data-no-answer="true">
	    
		</div>
		</div>
</div>
</div>
<!-- ChatBot end -->
<section class="home">

    <div class="slides-container">

        <div class="slide active">
            <div class="content">
                <span>Delicious Lattee</span>
                <h3>upto 70% off</h3>
                <a href="product_user.php" class="btn">order now...</a>
            </div>
            <div class="image">
                <img src="image/home-img-1.png" alt="">
            </div>
        </div>

        <div class="slide">
            <div class="content">
                <span>Great Expresso Martini</span><br>
				<span>An Oral Story history of an iconic cocktail</span>
                <h3>upto 50% off</h3>
                <a href="product_user.php" class="btn">order Now...</a>
            </div>
            <div class="image">
                <img src="image/expresso.png" alt="">
            </div>
        </div>

        <div class="slide">
            <div class="content">
                <span>Americano Delight</span>
                <h3>upto 50% off</h3>
                <a href="product_user.php" class="btn">order Now...</a>
            </div>
            <div class="image">
                <img src="image/americano.jpg" alt="">
            </div>
        </div>

    </div>

    <div id="next-slide" class="fas fa-angle-right" onclick="next()"></div>
    <div id="prev-slide" class="fas fa-angle-left" onclick="next()"></div>

</section>

<section class="banner-container">

    <div class="banner">
        <img src="image/doppio.jpg" alt="">
        <div class="content">
            <span>limited sales</span><br>
			<span>Dippio</span>
            <h3>upto 50% off</h3>
            <a href="product_user.php" class="btn">Order Now</a>
        </div>
    </div>

    <div class="banner">
        <img src="image/galao.jpg" alt="">
        <div class="content">
            <span>limited sales</span><br>
			<span>Galao</span>
            <h3>upto 50% off</h3>
            <a href="product_user.php" class="btn">Order now</a>
        </div>
    </div>

    <div class="banner">
        <img src="image/macchiato.jpg" alt="">
        <div class="content">
            <span>limited sales</span><br>
			<span>macchiato</span>
            <h3>upto 50% off</h3>
            <a href="product_user.php" class="btn">order now</a>
        </div>
    </div>

</section>

<!-- footer section starts  -->



<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href="home.html"> <i class="fas fa-arrow-right"></i> home</a>
            <a href="product_user.php"> <i class="fas fa-arrow-right"></i> shop</a>
            <a href="about.html"> <i class="fas fa-arrow-right"></i> about</a>
            <a href="review.html"> <i class="fas fa-arrow-right"></i> review</a>
            <a href="blog.html"> <i class="fas fa-arrow-right"></i> blog</a>
            <a href="contact.html"> <i class="fas fa-arrow-right"></i> contact</a>
        </div>

        <div class="box">
            <h3>extra links</h3>
            <a href="product_user.php"> <i class="fas fa-arrow-right"></i> my order </a>
            <a href="product_user.php"> <i class="fas fa-arrow-right"></i> my favorite </a>
            <a href="product_user.php"> <i class="fas fa-arrow-right"></i> my wishlist </a>
            <a href="product_user.php"> <i class="fas fa-arrow-right"></i> my account </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> terms or use </a>
        </div>

        <div class="box">
            <h3>follow us</h3>
            <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
            <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
            <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
            <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
            <a href="#"> <i class="fab fa-pinterest"></i> pinterest </a>
        </div>

        <div class="box">
            <h3>newsletter</h3>
            <p>subscribe for latest updates</p>
            <form action="">
                <input type="email" placeholder="enter your email">
                <input type="submit" value="subscribe" class="btn">
            </form>
            <img src="image/payment.png" class="payment" alt="">
        </div>

    </div>

</section>

<section class="credit"></section>

<!-- footer section ends -->

<!-- custom css file link  -->
<script src="css/js/script.js"></script>
<script type="text/javascript">
	portfolioList = document.querySelectorAll('.portfolio-box');
	portfolioList.forEach(function(portfolioPic) {
		portfolioPic.addEventListener('click',function(){
			bg = this.style.backgroundImage;
			document.getElementById('port_pop_pic_bg').classList.add("active")
			document.getElementById('port_pop_pic').style.backgroundImage = bg
			document.getElementById('port_pop_pic').classList.add("active")
		});	
	})
	document.getElementById('port_pop_pic_bg').addEventListener('click',function(){
			document.getElementById('port_pop_pic_bg').classList.remove("active")
			document.getElementById('port_pop_pic').classList.remove("active")
	})
</script>
<script>
		function order(stateWrapper, ready) {
			window.open("product_user.php");
			ready();
		}
		function bing(stateWrapper, ready) {
			window.open("https://bing.com");
			ready();
		}
		var rollbackTo = false;
		var originalState = false;
		function storeState(stateWrapper, ready) {
			rollbackTo = stateWrapper.current;
			console.log("storeState called: ",rollbackTo);
			ready();
		}
		function rollback(stateWrapper, ready) {
			console.log("rollback called: ", rollbackTo, originalState);
			console.log("answers at the time of user input: ", stateWrapper.answers);
			if(rollbackTo!=false) {
				if(originalState==false) {
					originalState = stateWrapper.current.next;
						console.log('stored original state');
				}
				stateWrapper.current.next = rollbackTo;
				console.log('changed current.next to rollbackTo');
			}
			ready();
		}
		function restore(stateWrapper, ready) {
			if(originalState != false) {
				stateWrapper.current.next = originalState;
				console.log('changed current.next to originalState');
			}
			ready();
		}
	</script>
	<script>
		jQuery(function($){
			convForm = $('#chat').convform({selectInputStyle: 'disable'});
			console.log(convForm);
		});
	</script>
</body>
</html>