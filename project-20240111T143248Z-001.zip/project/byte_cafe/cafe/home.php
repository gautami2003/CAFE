<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Byte Cafe</title>

	<!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
	
    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">
	


<!-- header section starts  -->

<header class="header">

    <a href="home.html" class="logo"> <i class="fas fa-"></i> Byte Cafe	 </a>

    <nav class="navbar">
        <a href="home.html">home</a>
        <a href="product.php">menu</a>
        <a href="about.html">about</a>
        <a href="review.html">review</a>
        <a href="contact.html">contact</a>
    </nav>

    <div class="icons">
        <div id="menu-btn" class="fas fa-bars"></div>
        <div id="search-btn" class="fas fa-search"></div>
        <div id="cart-btn" class="fas fa-shopping-cart"></div>
        <div id="login-btn" class="fas fa-user"></div>
		
    </div>

    <form action="" class="search-form">
        <input type="search" placeholder="search here..." id="search-box">
        <label for="search-box" class="fas fa-search"></label>
    </form>

    <div class="shopping-cart">
        <div class="box">
            <i class="fas fa-times"></i>
            <img src="image/cappuccino.jpg" alt="">
            <div class="content">	
                <h3>Capiccino</h3>
                <span class="quantity">1</span>
                <span class="multiply">x</span>
                <span class="price">$18.99</span>
            </div>
        </div>
        <div class="box">
            <i class="fas fa-times"></i>
            <img src="image/cart-2.jpg" alt="">
            <div class="content">
                <h3>Lattee</h3>
                <span class="quantity">1</span>
                <span class="multiply">x</span>
                <span class="price">$18.99</span>
            </div>
        </div>
        <div class="box">
            <i class="fas fa-times"></i>
            <img src="image/cart-3.jpg" alt="">
            <div class="content">
                <h3>Green Tea</h3>
                <span class="quantity">1</span>
                <span class="multiply">x</span>
                <span class="price">180.99</span>
            </div>
        </div>
        <h3 class="total"> total : <span>56.97</span> </h3>
        <a href="order.html" class="btn">checkout cart</a>
    </div>

    <form action="login.php" method="post">
		<div class="login-form">	
        <a href="login_form.php"><h3>login form</h3></a>
        
    </form>

</header>
</header>

<!-- header section ends -->

<section class="home">

    <div class="slides-container">

        <div class="slide active">
            <div class="content">
                <span>Delicious Lattee</span>
                <h3>upto 70% off</h3>
                <a href="menu.html" class="btn">order now...</a>
            </div>
            <div class="image">
                <img src="image/home-img-1.png" alt="">
            </div>
        </div>

        <div class="slide">
            <div class="content">
                <span>Great Expresso Martini</span><br>
				<span>An Oral Story history of an iconic cocktail</span>
                <h3>upto 50% off</h3>
                <a href="order.php" class="btn">order Now...</a>
            </div>
            <div class="image">
                <img src="image/expresso.png" alt="">
            </div>
        </div>

        <div class="slide">
            <div class="content">
                <span>Americano Delight</span>
                <h3>upto 50% off</h3>
                <a href="order.php" class="btn">order Now...</a>
            </div>
            <div class="image">
                <img src="image/americano.jpg" alt="">
            </div>
        </div>

    </div>

    <div id="next-slide" class="fas fa-angle-right" onclick="next()"></div>
    <div id="prev-slide" class="fas fa-angle-left" onclick="next()"></div>

</section>

<section class="banner-container">

    <div class="banner">
        <img src="image/doppio.jpg" alt="">
        <div class="content">
            <span>limited sales</span><br>
			<span>Dippio</span>
            <h3>upto 50% off</h3>
            <a href="order.html" class="btn">Order Now</a>
        </div>
    </div>

    <div class="banner">
        <img src="image/galao.jpg" alt="">
        <div class="content">
            <span>limited sales</span><br>
			<span>Galao</span>
            <h3>upto 50% off</h3>
            <a href="order.html" class="btn">Order now</a>
        </div>
    </div>

    <div class="banner">
        <img src="image/macchiato.jpg" alt="">
        <div class="content">
            <span>limited sales</span><br>
			<span>macchiato</span>
            <h3>upto 50% off</h3>
            <a href="order.html" class="btn">order now</a>
        </div>
    </div>

</section>

<!-- footer section starts  -->



<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>quick links</h3>
            <a href="home.html"> <i class="fas fa-arrow-right"></i> home</a>
            <a href="shop.html"> <i class="fas fa-arrow-right"></i> shop</a>
            <a href="about.html"> <i class="fas fa-arrow-right"></i> about</a>
            <a href="review.html"> <i class="fas fa-arrow-right"></i> review</a>
            <a href="blog.html"> <i class="fas fa-arrow-right"></i> blog</a>
            <a href="contact.html"> <i class="fas fa-arrow-right"></i> contact</a>
        </div>

        <div class="box">
            <h3>extra links</h3>
            <a href="order.php"> <i class="fas fa-arrow-right"></i> my order </a>
            <a href="order.php"> <i class="fas fa-arrow-right"></i> my favorite </a>
            <a href="order.php"> <i class="fas fa-arrow-right"></i> my wishlist </a>
            <a href="login.php"> <i class="fas fa-arrow-right"></i> my account </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> terms or use </a>
        </div>

        <div class="box">
            <h3>follow us</h3>
            <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
            <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
            <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
            <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
            <a href="#"> <i class="fab fa-pinterest"></i> pinterest </a>
        </div>

        <div class="box">
            <h3>newsletter</h3>
            <p>subscribe for latest updates</p>
            <form action="">
                <input type="email" placeholder="enter your email">
                <input type="submit" value="subscribe" class="btn">
            </form>
            <img src="image/payment.png" class="payment" alt="">
        </div>

    </div>

</section>

<section class="credit"></section>

<!-- footer section ends -->

<!-- custom css file link  -->
<script src="css/js/script.js"></script>

</body>
</html>